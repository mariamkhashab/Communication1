function [mq] = Decoder(dq, type, order)

mqhat=zeros(length(dq)+1);

for n=1:length(dq)
    
    if n==1
        mqhat(n)=0;
        mq(n)=dq(n);
    else
        mq(n)=dq(n)+mqhat(n);
    end
    if order==1
        mqhat(n+1)=mq(n);
    else
        if (n==1)
            mqhat(n+1)=mq(n)/2;
        else
            mqhat(n+1)=(mq(n)/2)+(mq(n-1)/2);
        end
        
    end
    
end
end



