function [dq,d] = Encoder(m, delta, type, order,L,am)
% m -> input samples
mhat=[]; % output of predictor
mq=[]; %  input of predictor
dq=[]; % encoded & quantized bits
d=[]; %differential samples & input to quantizer

for n=1:length(m)
    if n==1
        mhat(n)=0;
        d(n)=m(n)- mhat(n);
        dq(n)=uniform_quantizer_v1(d(n), L, am, type);
        mq(n)=dq(n)+ mhat(n);
    else
        d(n)=m(n)- mhat(n);
        dq(n)=uniform_quantizer_v1(d(n), L, am, type);
        mq(n)=dq(n)+ mhat(n);
    end
    if order==1
        mhat(n+1)=mq(n);
    else
        if (n==1)
            mhat(n+1)=mq(n)/2;
        else
            mhat(n+1)=(mq(n)/2)+(mq(n-1)/2);
        end
        
    end
    
end
end
